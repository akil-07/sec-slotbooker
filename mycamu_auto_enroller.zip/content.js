let settings = { autoEnroll: false, courseKeyword: '', sectionKeyword: '', bulkInput: '' };
let intervalId = null;

// --- Fake Mouse Cursor & Ripple ---
let fakeCursor = null;
let scrollDirection = 1;
const clickedKeywords = new Map(); // keyword -> lastClickedTimestamp

function createFakeCursor() {
    if (fakeCursor) return;

    const style = document.createElement('style');
    style.textContent = `
        @keyframes rippleOut {
            0% { transform: scale(0.5); opacity: 1; border-width: 4px; }
            100% { transform: scale(2.5); opacity: 0; border-width: 1px; }
        }
    `;
    document.head.appendChild(style);

    fakeCursor = document.createElement('div');
    fakeCursor.style.cssText = `
        position: fixed;
        width: 16px;
        height: 16px;
        background: #ff4500;
        border: 2px solid white;
        border-radius: 50%;
        box-shadow: 0 0 15px #ff4500, 0 0 30px #ff0000;
        z-index: 9999999;
        pointer-events: none;
        top: 50%;
        left: 50%;
        transition: top 0.4s cubic-bezier(0.2, 0.8, 0.2, 1), left 0.4s cubic-bezier(0.2, 0.8, 0.2, 1), opacity 0.3s;
        opacity: 0;
    `;
    document.body.appendChild(fakeCursor);
}

function isElementInViewport(el) {
    const rect = el.getBoundingClientRect();
    return (
        rect.top >= 0 &&
        rect.left >= 0 &&
        rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
        rect.right <= (window.innerWidth || document.documentElement.clientWidth)
    );
}

// --- Visual Debugging Toast ---
function showToast(message, color = '#333') {
    let existing = document.getElementById('mycamu-debug-toast');
    if (!existing) {
        existing = document.createElement('div');
        existing.id = 'mycamu-debug-toast';
        existing.style.cssText = `position: fixed; bottom: 20px; left: 20px; color: white; padding: 10px 15px; border-radius: 8px; z-index: 999999; font-family: sans-serif; font-size: 14px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); pointer-events: none;`;
        document.body.appendChild(existing);
    }
    existing.style.background = color;
    existing.innerText = message;

    // Auto clear after 3 seconds
    if (existing.timeoutId) clearTimeout(existing.timeoutId);
    existing.timeoutId = setTimeout(() => existing.remove(), 3000);
}

function scanAndEnroll() {
    if (!settings.autoEnroll) {
        if (fakeCursor) fakeCursor.style.opacity = '0';
        return;
    }

    createFakeCursor();

    // Build target array from bulk input or fallback to simple inputs
    const targets = [];
    const globalSection = (settings.sectionKeyword || '').trim().toLowerCase();

    if (settings.bulkInput && settings.bulkInput.trim()) {
        const lines = settings.bulkInput.split('\n');
        for (let line of lines) {
            if (!line.trim()) continue;
            const parts = line.split('|');
            if (parts.length >= 2) {
                targets.push({
                    course: parts[0].trim().toLowerCase(),
                    section: parts[1].trim().toLowerCase(),
                    globalSection: globalSection
                });
            } else if (parts.length === 1) {
                targets.push({
                    course: parts[0].trim().toLowerCase(),
                    section: '',
                    globalSection: globalSection
                });
            }
        }
    } else if (settings.courseKeyword) {
        const keywords = settings.courseKeyword.split(',').map(k => k.trim().toLowerCase()).filter(k => k);
        for (let kw of keywords) {
            targets.push({ course: kw, section: '', globalSection: globalSection });
        }
    }

    console.log('[Auto Enroller] Parsed targets:', targets);

    if (targets.length === 0) return;

    const allClickables = document.querySelectorAll('button, a, [role="button"], input[type="button"], input[type="submit"], input[type="checkbox"], input[type="radio"]');
    const validPoints = [];
    let anySlotFound = allClickables.length > 0; // Assume if there are clickables, slots might be open

    let buttonToClick = null;
    let matchedCourse = null;

    // 1. Search the page for the specific slot text first
    for (let t of targets) {
        // We prioritize searching for the section code (e.g. "T2-Q38") because it is uniquely on the same row as the button.
        const searchText = t.section ? t.section : t.course;
        if (!searchText) continue;
        
        // Escape quotes just in case
        const safeSearch = searchText.replace(/'/g, "");
        
        // Use XPath to find the exact text node containing our search text
        const xpath = `//text()[contains(translate(., 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), '${safeSearch}')]`;
        
        try {
            const snapshot = document.evaluate(xpath, document.body, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
            console.log(`[Auto Enroller] XPath search for '${safeSearch}' found ${snapshot.snapshotLength} matches.`);
            
            for (let i = 0; i < snapshot.snapshotLength; i++) {
                let node = snapshot.snapshotItem(i);
                console.log(`[Auto Enroller] Match ${i+1}:`, node.textContent.trim());
                
                // We found the text! Now let's look for the nearest clickable element near it.
                // We start from the text element and go up 15 levels to find the row container, looking for a button inside.
                let container = node.parentElement;
                let depth = 0;
                
                while (container && depth < 15) {
                    const buttonsInContainer = container.querySelectorAll('button, a, [role="button"], input[type="button"], input[type="submit"], input[type="checkbox"], input[type="radio"], .btn, [class*="btn"], [class*="button"]');
                    
                    if (buttonsInContainer.length > 0) {
                        // Just grab the first clickable element in this row!
                        const btn = buttonsInContainer[0];
                        console.log(`[Auto Enroller] Found clickable element at depth ${depth}:`, btn);
                        
                        // Check cooldown
                        const lastClicked = clickedKeywords.get(t.course) || 0;
                        if (Date.now() - lastClicked > 15000) {
                            buttonToClick = btn;
                            matchedCourse = t.course;
                            console.log(`[Auto Enroller] Target acquired!`);
                            break;
                        } else {
                            console.log(`[Auto Enroller] Button found but it is on cooldown.`);
                        }
                    }
                    
                    container = container.parentElement;
                    depth++;
                }
                
                if (buttonToClick) break;
            }
        } catch (e) {
            console.error("[Auto Enroller] XPath error:", e);
        }
        
        if (buttonToClick) break;
    }

    if (buttonToClick) {
        validPoints.push({
            element: buttonToClick,
            keyword: matchedCourse
        });
    }

    if (validPoints.length > 0) {
        isRapidScrolling = false; // Stop rapid scrolling if we found the target
        const pt = validPoints[0];

        clickedKeywords.set(pt.keyword, Date.now());

        if (!isElementInViewport(pt.element)) {
            pt.element.scrollIntoView({ behavior: 'auto', block: 'center' });
        }

        showToast(`🎯 Target Acquired! Gliding to click...`, '#1a73e8');

        setTimeout(() => {
            if (!settings.autoEnroll) {
                if (fakeCursor) fakeCursor.style.opacity = '0';
                return;
            }

            const rect = pt.element.getBoundingClientRect();
            const exactX = Math.round(rect.left + rect.width / 2);
            const exactY = Math.round(rect.top + rect.height / 2);

            fakeCursor.style.opacity = '1';
            fakeCursor.style.left = (exactX - 8) + 'px';
            fakeCursor.style.top = (exactY - 8) + 'px';

            setTimeout(() => {
                if (!settings.autoEnroll) {
                    fakeCursor.style.opacity = '0';
                    return;
                }

                const ripple = document.createElement('div');
                ripple.style.cssText = `position: fixed; left: ${exactX - 25}px; top: ${exactY - 25}px; width: 50px; height: 50px; border: 2px solid #ff4500; border-radius: 50%; z-index: 9999998; pointer-events: none; animation: rippleOut 0.5s ease-out forwards;`;
                document.body.appendChild(ripple);
                setTimeout(() => ripple.remove(), 500);

                chrome.runtime.sendMessage({ type: 'REAL_CLICK', points: [{ x: exactX, y: exactY }] }).catch(() => { });
                chrome.runtime.sendMessage({ type: 'CLICKED' }).catch(() => { });

            }, 400);
        }, 50);
    } else {
        if (fakeCursor) fakeCursor.style.opacity = '0';
        
        // If slots are open but our target isn't found yet, safely scroll down to load more.
        if (settings.autoEnroll && targets.length > 0) {
            if (anySlotFound) {
                showToast('⏬ Slots open! Scrolling to hunt targets...', '#ffaa00');
                window.scrollBy(0, 600);
            } else {
                showToast('👀 Scanning for slots to open...', '#333');
            }
        }
    }
}

function startScanning() {
    if (intervalId) clearInterval(intervalId);
    if (!settings.autoEnroll) return;

    console.log('[Auto Enroller] Started scanning for:', settings.courseKeyword);
    scanAndEnroll();
    intervalId = setInterval(scanAndEnroll, 600); // scan every 600ms
}

function stopScanning() {
    if (intervalId) clearInterval(intervalId);
    intervalId = null;
    console.log('[Auto Enroller] Stopped scanning');
}

// Listen for storage changes from the popup
chrome.storage.onChanged.addListener((changes) => {
    let changed = false;
    if (changes.autoEnroll !== undefined) {
        settings.autoEnroll = changes.autoEnroll.newValue;
        changed = true;
    }
    if (changes.courseKeyword !== undefined) {
        settings.courseKeyword = changes.courseKeyword.newValue;
        changed = true;
    }
    if (changes.sectionKeyword !== undefined) {
        settings.sectionKeyword = changes.sectionKeyword.newValue;
        changed = true;
    }
    if (changes.bulkInput !== undefined) {
        settings.bulkInput = changes.bulkInput.newValue;
        changed = true;
    }

    if (changed) {
        if (settings.autoEnroll) startScanning();
        else stopScanning();
    }
});

// Initial load on page visit
chrome.storage.local.get(['autoEnroll', 'courseKeyword', 'sectionKeyword', 'bulkInput'], (stored) => {
    settings.autoEnroll = stored.autoEnroll ?? false;
    settings.courseKeyword = stored.courseKeyword ?? '';
    settings.sectionKeyword = stored.sectionKeyword ?? '';
    settings.bulkInput = stored.bulkInput ?? '';

    if (settings.autoEnroll) startScanning();
});

// Listen for messages from popup
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === 'AUTO_SCROLL') {
        showToast('⏬ Auto-scrolling to load full page...', '#ffaa00');
        
        let scrollCount = 0;
        let prevHeight = 0;
        const scrollInterval = setInterval(() => {
            window.scrollBy(0, 800); // Scroll down 800px
            scrollCount++;
            
            // Check if we hit the bottom (height stopped changing) every 3 scrolls
            if (scrollCount % 3 === 0) {
                const currentHeight = document.body.scrollHeight;
                if (currentHeight === prevHeight) {
                    clearInterval(scrollInterval);
                    showToast('✅ Finished loading page!', '#10b981');
                    window.scrollTo({ top: 0, behavior: 'smooth' }); // Go back to top
                } else {
                    prevHeight = currentHeight;
                }
            }
            
            // Failsafe limit
            if (scrollCount > 200) {
                clearInterval(scrollInterval);
                showToast('⏹️ Auto-scroll stopped (limit reached)', '#333');
            }
        }, 300);
    }
});
